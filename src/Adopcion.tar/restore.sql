--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Adopcion_Per";
--
-- Name: Adopcion_Per; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Adopcion_Per" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Mexico.1252';


ALTER DATABASE "Adopcion_Per" OWNER TO postgres;

\connect "Adopcion_Per"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: actualizar_cuestionario(integer, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_cuestionario(IN p_id integer, IN p_descripcion text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE Cuestionario SET descripcion = p_descripcion WHERE id_cuestionario = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_cuestionario(IN p_id integer, IN p_descripcion text) OWNER TO postgres;

--
-- Name: actualizar_estado_adopcion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.actualizar_estado_adopcion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.estado_solicitud = 'aprobada' THEN
        UPDATE Mascota
        SET estado_adopcion = 'adoptada'
        WHERE id_mascota = NEW.id_mascota;
    ELSE
        UPDATE Mascota
        SET estado_adopcion = 'en proceso'
        WHERE id_mascota = NEW.id_mascota;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.actualizar_estado_adopcion() OWNER TO postgres;

--
-- Name: actualizar_mascota(integer, character varying, character varying, character varying, integer, character varying, text, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_mascota(IN p_id integer, IN p_nombre character varying, IN p_especie character varying, IN p_raza character varying, IN p_edad integer, IN p_sexo character varying, IN p_descripcion text, IN p_estado_adopcion character varying, IN p_lugar_actual character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE Mascota SET nombre = p_nombre, especie = p_especie, raza = p_raza, edad = p_edad, sexo = p_sexo, descripcion = p_descripcion, estado_adopcion = p_estado_adopcion, lugar_actual = p_lugar_actual
    WHERE id_mascota = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_mascota(IN p_id integer, IN p_nombre character varying, IN p_especie character varying, IN p_raza character varying, IN p_edad integer, IN p_sexo character varying, IN p_descripcion text, IN p_estado_adopcion character varying, IN p_lugar_actual character varying) OWNER TO postgres;

--
-- Name: actualizar_mascota_tipo(integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_mascota_tipo(IN p_id_mascota integer, IN p_id_emocional_old integer, IN p_id_emocional_new integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE MascotaTipo SET id_emocional = p_id_emocional_new WHERE id_mascota = p_id_mascota AND id_emocional = p_id_emocional_old;
END;
$$;


ALTER PROCEDURE public.actualizar_mascota_tipo(IN p_id_mascota integer, IN p_id_emocional_old integer, IN p_id_emocional_new integer) OWNER TO postgres;

--
-- Name: actualizar_opcion_respuesta(integer, text, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_opcion_respuesta(IN p_id integer, IN p_texto_opcion text, IN p_id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE OpcionRespuesta SET texto_opcion = p_texto_opcion, id_emocional = p_id_emocional WHERE id_opcion = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_opcion_respuesta(IN p_id integer, IN p_texto_opcion text, IN p_id_emocional integer) OWNER TO postgres;

--
-- Name: actualizar_pregunta(integer, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_pregunta(IN p_id integer, IN p_texto_pregunta text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE Pregunta SET texto_pregunta = p_texto_pregunta WHERE id_pregunta = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_pregunta(IN p_id integer, IN p_texto_pregunta text) OWNER TO postgres;

--
-- Name: actualizar_resultado_usuario(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_resultado_usuario(IN p_id integer, IN p_id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE ResultadoUsuario SET id_emocional = p_id_emocional WHERE id_resultado = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_resultado_usuario(IN p_id integer, IN p_id_emocional integer) OWNER TO postgres;

--
-- Name: actualizar_solicitud(integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_solicitud(IN p_id integer, IN p_estado_solicitud character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE SolicitudAdopcion SET estado_solicitud = p_estado_solicitud WHERE id_solicitud = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_solicitud(IN p_id integer, IN p_estado_solicitud character varying) OWNER TO postgres;

--
-- Name: actualizar_tipo_emocional(integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_tipo_emocional(IN p_id integer, IN p_descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE TipoEmocional SET descripcion = p_descripcion WHERE id_emocional = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_tipo_emocional(IN p_id integer, IN p_descripcion character varying) OWNER TO postgres;

--
-- Name: actualizar_usuario(integer, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.actualizar_usuario(IN p_id integer, IN p_nombre character varying, IN p_email character varying, IN p_telefono character varying, IN p_direccion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE Usuario SET nombre = p_nombre, email = p_email, telefono = p_telefono, direccion = p_direccion WHERE id_usuario = p_id;
END;
$$;


ALTER PROCEDURE public.actualizar_usuario(IN p_id integer, IN p_nombre character varying, IN p_email character varying, IN p_telefono character varying, IN p_direccion character varying) OWNER TO postgres;

--
-- Name: asignar_tipo_emocional_usuario(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.asignar_tipo_emocional_usuario() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE Usuario
    SET tipo_emocional = NEW.id_emocional
    WHERE id_usuario = NEW.id_usuario;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.asignar_tipo_emocional_usuario() OWNER TO postgres;

--
-- Name: eliminar_cuestionario(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_cuestionario(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM Cuestionario WHERE id_cuestionario = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_cuestionario(IN p_id integer) OWNER TO postgres;

--
-- Name: eliminar_mascota(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_mascota(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM Mascota WHERE id_mascota = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_mascota(IN p_id integer) OWNER TO postgres;

--
-- Name: eliminar_mascota_tipo(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_mascota_tipo(IN p_id_mascota integer, IN p_id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM MascotaTipo WHERE id_mascota = p_id_mascota AND id_emocional = p_id_emocional;
END;
$$;


ALTER PROCEDURE public.eliminar_mascota_tipo(IN p_id_mascota integer, IN p_id_emocional integer) OWNER TO postgres;

--
-- Name: eliminar_opcion_respuesta(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_opcion_respuesta(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM OpcionRespuesta WHERE id_opcion = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_opcion_respuesta(IN p_id integer) OWNER TO postgres;

--
-- Name: eliminar_pregunta(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_pregunta(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM Pregunta WHERE id_pregunta = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_pregunta(IN p_id integer) OWNER TO postgres;

--
-- Name: eliminar_resultado_usuario(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_resultado_usuario(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM ResultadoUsuario WHERE id_resultado = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_resultado_usuario(IN p_id integer) OWNER TO postgres;

--
-- Name: eliminar_solicitud(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_solicitud(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM SolicitudAdopcion WHERE id_solicitud = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_solicitud(IN p_id integer) OWNER TO postgres;

--
-- Name: eliminar_tipo_emocional(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_tipo_emocional(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM TipoEmocional WHERE id_emocional = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_tipo_emocional(IN p_id integer) OWNER TO postgres;

--
-- Name: eliminar_usuario(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.eliminar_usuario(IN p_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM Usuario WHERE id_usuario = p_id;
END;
$$;


ALTER PROCEDURE public.eliminar_usuario(IN p_id integer) OWNER TO postgres;

--
-- Name: insertar_cuestionario(text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_cuestionario(IN p_descripcion text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Cuestionario (descripcion)
    VALUES (p_descripcion);
END;
$$;


ALTER PROCEDURE public.insertar_cuestionario(IN p_descripcion text) OWNER TO postgres;

--
-- Name: insertar_mascota(character varying, character varying, character varying, integer, character varying, text, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_mascota(IN p_nombre character varying, IN p_especie character varying, IN p_raza character varying, IN p_edad integer, IN p_sexo character varying, IN p_descripcion text, IN p_lugar_actual character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Mascota (nombre, especie, raza, edad, sexo, descripcion, lugar_actual)
    VALUES (p_nombre, p_especie, p_raza, p_edad, p_sexo, p_descripcion, p_lugar_actual);
END;
$$;


ALTER PROCEDURE public.insertar_mascota(IN p_nombre character varying, IN p_especie character varying, IN p_raza character varying, IN p_edad integer, IN p_sexo character varying, IN p_descripcion text, IN p_lugar_actual character varying) OWNER TO postgres;

--
-- Name: insertar_mascota_tipo(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_mascota_tipo(IN p_id_mascota integer, IN p_id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO MascotaTipo (id_mascota, id_emocional)
    VALUES (p_id_mascota, p_id_emocional);
END;
$$;


ALTER PROCEDURE public.insertar_mascota_tipo(IN p_id_mascota integer, IN p_id_emocional integer) OWNER TO postgres;

--
-- Name: insertar_opcion_respuesta(integer, text, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_opcion_respuesta(IN p_id_pregunta integer, IN p_texto_opcion text, IN p_id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO OpcionRespuesta (id_pregunta, texto_opcion, id_emocional)
    VALUES (p_id_pregunta, p_texto_opcion, p_id_emocional);
END;
$$;


ALTER PROCEDURE public.insertar_opcion_respuesta(IN p_id_pregunta integer, IN p_texto_opcion text, IN p_id_emocional integer) OWNER TO postgres;

--
-- Name: insertar_pregunta(integer, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_pregunta(IN p_id_cuestionario integer, IN p_texto_pregunta text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Pregunta (id_cuestionario, texto_pregunta)
    VALUES (p_id_cuestionario, p_texto_pregunta);
END;
$$;


ALTER PROCEDURE public.insertar_pregunta(IN p_id_cuestionario integer, IN p_texto_pregunta text) OWNER TO postgres;

--
-- Name: insertar_resultado_usuario(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_resultado_usuario(IN p_id_usuario integer, IN p_id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO ResultadoUsuario (id_usuario, id_emocional)
    VALUES (p_id_usuario, p_id_emocional);
END;
$$;


ALTER PROCEDURE public.insertar_resultado_usuario(IN p_id_usuario integer, IN p_id_emocional integer) OWNER TO postgres;

--
-- Name: insertar_solicitud(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_solicitud(IN p_id_usuario integer, IN p_id_mascota integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO SolicitudAdopcion (id_usuario, id_mascota)
    VALUES (p_id_usuario, p_id_mascota);
END;
$$;


ALTER PROCEDURE public.insertar_solicitud(IN p_id_usuario integer, IN p_id_mascota integer) OWNER TO postgres;

--
-- Name: insertar_tipo_emocional(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_tipo_emocional(IN p_descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO TipoEmocional (descripcion)
    VALUES (p_descripcion);
END;
$$;


ALTER PROCEDURE public.insertar_tipo_emocional(IN p_descripcion character varying) OWNER TO postgres;

--
-- Name: insertar_usuario(character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertar_usuario(IN p_nombre character varying, IN p_email character varying, IN p_telefono character varying, IN p_direccion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Usuario (nombre, email, telefono, direccion)
    VALUES (p_nombre, p_email, p_telefono, p_direccion);
END;
$$;


ALTER PROCEDURE public.insertar_usuario(IN p_nombre character varying, IN p_email character varying, IN p_telefono character varying, IN p_direccion character varying) OWNER TO postgres;

--
-- Name: listar_cuestionarios(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_cuestionarios() RETURNS TABLE(id_cuestionario integer, descripcion text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM Cuestionario;
END;
$$;


ALTER FUNCTION public.listar_cuestionarios() OWNER TO postgres;

--
-- Name: listar_mascota_tipos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_mascota_tipos() RETURNS TABLE(id_mascota integer, id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM MascotaTipo;
END;
$$;


ALTER FUNCTION public.listar_mascota_tipos() OWNER TO postgres;

--
-- Name: listar_mascotas(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_mascotas() RETURNS TABLE(id_mascota integer, nombre character varying, especie character varying, raza character varying, edad integer, sexo character varying, descripcion text, estado_adopcion character varying, lugar_actual character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM Mascota;
END;
$$;


ALTER FUNCTION public.listar_mascotas() OWNER TO postgres;

--
-- Name: listar_opciones_respuesta(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_opciones_respuesta() RETURNS TABLE(id_opcion integer, id_pregunta integer, texto_opcion text, id_emocional integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM OpcionRespuesta;
END;
$$;


ALTER FUNCTION public.listar_opciones_respuesta() OWNER TO postgres;

--
-- Name: listar_preguntas(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_preguntas() RETURNS TABLE(id_pregunta integer, id_cuestionario integer, texto_pregunta text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM Pregunta;
END;
$$;


ALTER FUNCTION public.listar_preguntas() OWNER TO postgres;

--
-- Name: listar_resultados_usuario(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_resultados_usuario() RETURNS TABLE(id_resultado integer, id_usuario integer, id_emocional integer, fecha_resultado date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM ResultadoUsuario;
END;
$$;


ALTER FUNCTION public.listar_resultados_usuario() OWNER TO postgres;

--
-- Name: listar_solicitudes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_solicitudes() RETURNS TABLE(id_solicitud integer, id_usuario integer, id_mascota integer, fecha_solicitud date, estado_solicitud character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM SolicitudAdopcion;
END;
$$;


ALTER FUNCTION public.listar_solicitudes() OWNER TO postgres;

--
-- Name: listar_tipos_emocionales(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_tipos_emocionales() RETURNS TABLE(id_emocional integer, descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM TipoEmocional;
END;
$$;


ALTER FUNCTION public.listar_tipos_emocionales() OWNER TO postgres;

--
-- Name: listar_usuarios(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.listar_usuarios() RETURNS TABLE(id_usuario integer, nombre character varying, email character varying, telefono character varying, direccion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY SELECT * FROM Usuario;
END;
$$;


ALTER FUNCTION public.listar_usuarios() OWNER TO postgres;

--
-- Name: verificar_tipo_emocional_usuario(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verificar_tipo_emocional_usuario() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM ResultadoUsuario WHERE id_usuario = NEW.id_usuario) THEN
        RAISE EXCEPTION 'El usuario ya tiene un tipo emocional asignado.';
    ELSE
        RETURN NEW;
    END IF;
END;
$$;


ALTER FUNCTION public.verificar_tipo_emocional_usuario() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mascotatipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mascotatipo (
    id_mascota integer NOT NULL,
    id_emocional integer NOT NULL
);


ALTER TABLE public.mascotatipo OWNER TO postgres;

--
-- Name: tipoemocional; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipoemocional (
    id_emocional integer NOT NULL,
    descripcion character varying(50) NOT NULL
);


ALTER TABLE public.tipoemocional OWNER TO postgres;

--
-- Name: conteoporemocional_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.conteoporemocional_view AS
 SELECT te.descripcion AS tipo_emocional,
    count(*) AS total_mascotas
   FROM (public.mascotatipo mt
     JOIN public.tipoemocional te ON ((mt.id_emocional = te.id_emocional)))
  GROUP BY te.descripcion;


ALTER VIEW public.conteoporemocional_view OWNER TO postgres;

--
-- Name: cuestionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cuestionario (
    id_cuestionario integer NOT NULL,
    descripcion text
);


ALTER TABLE public.cuestionario OWNER TO postgres;

--
-- Name: cuestionario_id_cuestionario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cuestionario_id_cuestionario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cuestionario_id_cuestionario_seq OWNER TO postgres;

--
-- Name: cuestionario_id_cuestionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cuestionario_id_cuestionario_seq OWNED BY public.cuestionario.id_cuestionario;


--
-- Name: mascota; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mascota (
    id_mascota integer NOT NULL,
    nombre character varying(100) NOT NULL,
    especie character varying(50),
    tamano character varying(50),
    edad integer NOT NULL,
    sexo character varying(20) NOT NULL,
    descripcion text NOT NULL,
    estado_adopcion character varying(20) DEFAULT 'disponible'::character varying NOT NULL,
    lugar_actual character varying(100),
    CONSTRAINT chk_estado_adopcion CHECK (((estado_adopcion)::text = ANY ((ARRAY['disponible'::character varying, 'adoptado'::character varying, 'en_proceso'::character varying, 'reservado'::character varying])::text[]))),
    CONSTRAINT chk_sexo CHECK (((sexo)::text = ANY ((ARRAY['Macho'::character varying, 'Hembra'::character varying, 'Desconocido'::character varying])::text[])))
);


ALTER TABLE public.mascota OWNER TO postgres;

--
-- Name: mascota_id_mascota_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mascota_id_mascota_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mascota_id_mascota_seq OWNER TO postgres;

--
-- Name: mascota_id_mascota_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mascota_id_mascota_seq OWNED BY public.mascota.id_mascota;


--
-- Name: mascotasexo_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.mascotasexo_view AS
 SELECT nombre,
    especie,
    tamano AS raza,
    edad,
    sexo
   FROM public.mascota;


ALTER VIEW public.mascotasexo_view OWNER TO postgres;

--
-- Name: solicitudadopcion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.solicitudadopcion (
    id_solicitud integer NOT NULL,
    id_usuario integer,
    id_mascota integer,
    fecha_solicitud date DEFAULT CURRENT_DATE,
    estado_solicitud character varying(20) DEFAULT 'en_revision'::character varying,
    CONSTRAINT chk_estado_solicitud CHECK (((estado_solicitud)::text = ANY ((ARRAY['en_revision'::character varying, 'aprobada'::character varying, 'rechazada'::character varying, 'cancelada'::character varying])::text[])))
);


ALTER TABLE public.solicitudadopcion OWNER TO postgres;

--
-- Name: mascotassinsolicitud_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.mascotassinsolicitud_view AS
 SELECT m.id_mascota,
    m.nombre,
    m.especie,
    m.tamano AS raza,
    m.edad,
    m.sexo,
    m.descripcion,
    m.estado_adopcion,
    m.lugar_actual
   FROM (public.mascota m
     LEFT JOIN public.solicitudadopcion s ON ((m.id_mascota = s.id_mascota)))
  WHERE ((s.id_solicitud IS NULL) AND ((m.estado_adopcion)::text = 'disponible'::text));


ALTER VIEW public.mascotassinsolicitud_view OWNER TO postgres;

--
-- Name: mascotatipoemocional_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.mascotatipoemocional_view AS
 SELECT m.nombre,
    m.tamano AS raza,
    string_agg((t.descripcion)::text, ', '::text) AS tipos_emocionales
   FROM ((public.mascota m
     JOIN public.mascotatipo mt ON ((m.id_mascota = mt.id_mascota)))
     JOIN public.tipoemocional t ON ((t.id_emocional = mt.id_emocional)))
  GROUP BY m.nombre, m.tamano;


ALTER VIEW public.mascotatipoemocional_view OWNER TO postgres;

--
-- Name: opcionrespuesta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opcionrespuesta (
    id_opcion integer NOT NULL,
    id_pregunta integer,
    texto_opcion text NOT NULL,
    id_emocional integer
);


ALTER TABLE public.opcionrespuesta OWNER TO postgres;

--
-- Name: opcionrespuesta_id_opcion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.opcionrespuesta_id_opcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.opcionrespuesta_id_opcion_seq OWNER TO postgres;

--
-- Name: opcionrespuesta_id_opcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.opcionrespuesta_id_opcion_seq OWNED BY public.opcionrespuesta.id_opcion;


--
-- Name: pregunta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pregunta (
    id_pregunta integer NOT NULL,
    id_cuestionario integer,
    texto_pregunta text NOT NULL
);


ALTER TABLE public.pregunta OWNER TO postgres;

--
-- Name: pregunta_id_pregunta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pregunta_id_pregunta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pregunta_id_pregunta_seq OWNER TO postgres;

--
-- Name: pregunta_id_pregunta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pregunta_id_pregunta_seq OWNED BY public.pregunta.id_pregunta;


--
-- Name: resultadousuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resultadousuario (
    id_resultado integer NOT NULL,
    id_usuario integer,
    id_emocional integer,
    fecha_resultado date DEFAULT CURRENT_DATE
);


ALTER TABLE public.resultadousuario OWNER TO postgres;

--
-- Name: resultadousuario_id_resultado_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.resultadousuario_id_resultado_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.resultadousuario_id_resultado_seq OWNER TO postgres;

--
-- Name: resultadousuario_id_resultado_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.resultadousuario_id_resultado_seq OWNED BY public.resultadousuario.id_resultado;


--
-- Name: solicitudadopcion_id_solicitud_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.solicitudadopcion_id_solicitud_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.solicitudadopcion_id_solicitud_seq OWNER TO postgres;

--
-- Name: solicitudadopcion_id_solicitud_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.solicitudadopcion_id_solicitud_seq OWNED BY public.solicitudadopcion.id_solicitud;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    id_usuario integer NOT NULL,
    nombre character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    telefono character varying(20),
    direccion character varying(200),
    CONSTRAINT chk_email CHECK (((email)::text ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::text))
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: solicitudescompletas_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.solicitudescompletas_view AS
 SELECT s.id_solicitud,
    s.fecha_solicitud,
    s.estado_solicitud,
    u.nombre AS nombre_usuario,
    u.email,
    m.nombre AS nombre_mascota,
    m.especie
   FROM ((public.solicitudadopcion s
     JOIN public.usuario u ON ((s.id_usuario = u.id_usuario)))
     JOIN public.mascota m ON ((s.id_mascota = m.id_mascota)));


ALTER VIEW public.solicitudescompletas_view OWNER TO postgres;

--
-- Name: tipoemocional_id_emocional_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipoemocional_id_emocional_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipoemocional_id_emocional_seq OWNER TO postgres;

--
-- Name: tipoemocional_id_emocional_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipoemocional_id_emocional_seq OWNED BY public.tipoemocional.id_emocional;


--
-- Name: usuario_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_id_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuario_id_usuario_seq OWNER TO postgres;

--
-- Name: usuario_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_id_usuario_seq OWNED BY public.usuario.id_usuario;


--
-- Name: usuarioresultadoperfil_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.usuarioresultadoperfil_view AS
 SELECT DISTINCT ON (ru.id_usuario) u.id_usuario,
    u.nombre,
    u.email,
    te.descripcion AS perfil_emocional,
    ru.fecha_resultado
   FROM ((public.resultadousuario ru
     JOIN public.usuario u ON ((u.id_usuario = ru.id_usuario)))
     JOIN public.tipoemocional te ON ((te.id_emocional = ru.id_emocional)))
  ORDER BY ru.id_usuario, ru.fecha_resultado DESC;


ALTER VIEW public.usuarioresultadoperfil_view OWNER TO postgres;

--
-- Name: cuestionario id_cuestionario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuestionario ALTER COLUMN id_cuestionario SET DEFAULT nextval('public.cuestionario_id_cuestionario_seq'::regclass);


--
-- Name: mascota id_mascota; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mascota ALTER COLUMN id_mascota SET DEFAULT nextval('public.mascota_id_mascota_seq'::regclass);


--
-- Name: opcionrespuesta id_opcion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opcionrespuesta ALTER COLUMN id_opcion SET DEFAULT nextval('public.opcionrespuesta_id_opcion_seq'::regclass);


--
-- Name: pregunta id_pregunta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pregunta ALTER COLUMN id_pregunta SET DEFAULT nextval('public.pregunta_id_pregunta_seq'::regclass);


--
-- Name: resultadousuario id_resultado; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resultadousuario ALTER COLUMN id_resultado SET DEFAULT nextval('public.resultadousuario_id_resultado_seq'::regclass);


--
-- Name: solicitudadopcion id_solicitud; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitudadopcion ALTER COLUMN id_solicitud SET DEFAULT nextval('public.solicitudadopcion_id_solicitud_seq'::regclass);


--
-- Name: tipoemocional id_emocional; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoemocional ALTER COLUMN id_emocional SET DEFAULT nextval('public.tipoemocional_id_emocional_seq'::regclass);


--
-- Name: usuario id_usuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN id_usuario SET DEFAULT nextval('public.usuario_id_usuario_seq'::regclass);


--
-- Data for Name: cuestionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cuestionario (id_cuestionario, descripcion) FROM stdin;
\.
COPY public.cuestionario (id_cuestionario, descripcion) FROM '$$PATH$$/4952.dat';

--
-- Data for Name: mascota; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mascota (id_mascota, nombre, especie, tamano, edad, sexo, descripcion, estado_adopcion, lugar_actual) FROM stdin;
\.
COPY public.mascota (id_mascota, nombre, especie, tamano, edad, sexo, descripcion, estado_adopcion, lugar_actual) FROM '$$PATH$$/4943.dat';

--
-- Data for Name: mascotatipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mascotatipo (id_mascota, id_emocional) FROM stdin;
\.
COPY public.mascotatipo (id_mascota, id_emocional) FROM '$$PATH$$/4946.dat';

--
-- Data for Name: opcionrespuesta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opcionrespuesta (id_opcion, id_pregunta, texto_opcion, id_emocional) FROM stdin;
\.
COPY public.opcionrespuesta (id_opcion, id_pregunta, texto_opcion, id_emocional) FROM '$$PATH$$/4956.dat';

--
-- Data for Name: pregunta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pregunta (id_pregunta, id_cuestionario, texto_pregunta) FROM stdin;
\.
COPY public.pregunta (id_pregunta, id_cuestionario, texto_pregunta) FROM '$$PATH$$/4954.dat';

--
-- Data for Name: resultadousuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resultadousuario (id_resultado, id_usuario, id_emocional, fecha_resultado) FROM stdin;
\.
COPY public.resultadousuario (id_resultado, id_usuario, id_emocional, fecha_resultado) FROM '$$PATH$$/4958.dat';

--
-- Data for Name: solicitudadopcion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.solicitudadopcion (id_solicitud, id_usuario, id_mascota, fecha_solicitud, estado_solicitud) FROM stdin;
\.
COPY public.solicitudadopcion (id_solicitud, id_usuario, id_mascota, fecha_solicitud, estado_solicitud) FROM '$$PATH$$/4950.dat';

--
-- Data for Name: tipoemocional; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipoemocional (id_emocional, descripcion) FROM stdin;
\.
COPY public.tipoemocional (id_emocional, descripcion) FROM '$$PATH$$/4945.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (id_usuario, nombre, email, telefono, direccion) FROM stdin;
\.
COPY public.usuario (id_usuario, nombre, email, telefono, direccion) FROM '$$PATH$$/4948.dat';

--
-- Name: cuestionario_id_cuestionario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cuestionario_id_cuestionario_seq', 2, true);


--
-- Name: mascota_id_mascota_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mascota_id_mascota_seq', 9, true);


--
-- Name: opcionrespuesta_id_opcion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.opcionrespuesta_id_opcion_seq', 2, true);


--
-- Name: pregunta_id_pregunta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pregunta_id_pregunta_seq', 2, true);


--
-- Name: resultadousuario_id_resultado_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.resultadousuario_id_resultado_seq', 2, true);


--
-- Name: solicitudadopcion_id_solicitud_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.solicitudadopcion_id_solicitud_seq', 4, true);


--
-- Name: tipoemocional_id_emocional_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipoemocional_id_emocional_seq', 6, true);


--
-- Name: usuario_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_id_usuario_seq', 4, true);


--
-- Name: cuestionario cuestionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuestionario
    ADD CONSTRAINT cuestionario_pkey PRIMARY KEY (id_cuestionario);


--
-- Name: mascota mascota_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mascota
    ADD CONSTRAINT mascota_pkey PRIMARY KEY (id_mascota);


--
-- Name: mascotatipo mascotatipo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mascotatipo
    ADD CONSTRAINT mascotatipo_pkey PRIMARY KEY (id_mascota, id_emocional);


--
-- Name: opcionrespuesta opcionrespuesta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opcionrespuesta
    ADD CONSTRAINT opcionrespuesta_pkey PRIMARY KEY (id_opcion);


--
-- Name: pregunta pregunta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pregunta
    ADD CONSTRAINT pregunta_pkey PRIMARY KEY (id_pregunta);


--
-- Name: resultadousuario resultadousuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resultadousuario
    ADD CONSTRAINT resultadousuario_pkey PRIMARY KEY (id_resultado);


--
-- Name: solicitudadopcion solicitudadopcion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitudadopcion
    ADD CONSTRAINT solicitudadopcion_pkey PRIMARY KEY (id_solicitud);


--
-- Name: tipoemocional tipoemocional_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoemocional
    ADD CONSTRAINT tipoemocional_pkey PRIMARY KEY (id_emocional);


--
-- Name: usuario usuario_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_email_key UNIQUE (email);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: solicitudadopcion trigger_actualizar_estado_adopcion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_actualizar_estado_adopcion AFTER INSERT OR UPDATE ON public.solicitudadopcion FOR EACH ROW EXECUTE FUNCTION public.actualizar_estado_adopcion();


--
-- Name: resultadousuario trigger_asignar_tipo_emocional_usuario; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_asignar_tipo_emocional_usuario AFTER INSERT ON public.resultadousuario FOR EACH ROW EXECUTE FUNCTION public.asignar_tipo_emocional_usuario();


--
-- Name: resultadousuario trigger_verificar_tipo_emocional; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_verificar_tipo_emocional AFTER INSERT ON public.resultadousuario FOR EACH ROW EXECUTE FUNCTION public.verificar_tipo_emocional_usuario();


--
-- Name: mascotatipo mascotatipo_id_emocional_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mascotatipo
    ADD CONSTRAINT mascotatipo_id_emocional_fkey FOREIGN KEY (id_emocional) REFERENCES public.tipoemocional(id_emocional);


--
-- Name: mascotatipo mascotatipo_id_mascota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mascotatipo
    ADD CONSTRAINT mascotatipo_id_mascota_fkey FOREIGN KEY (id_mascota) REFERENCES public.mascota(id_mascota);


--
-- Name: opcionrespuesta opcionrespuesta_id_emocional_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opcionrespuesta
    ADD CONSTRAINT opcionrespuesta_id_emocional_fkey FOREIGN KEY (id_emocional) REFERENCES public.tipoemocional(id_emocional);


--
-- Name: opcionrespuesta opcionrespuesta_id_pregunta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opcionrespuesta
    ADD CONSTRAINT opcionrespuesta_id_pregunta_fkey FOREIGN KEY (id_pregunta) REFERENCES public.pregunta(id_pregunta);


--
-- Name: pregunta pregunta_id_cuestionario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pregunta
    ADD CONSTRAINT pregunta_id_cuestionario_fkey FOREIGN KEY (id_cuestionario) REFERENCES public.cuestionario(id_cuestionario);


--
-- Name: resultadousuario resultadousuario_id_emocional_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resultadousuario
    ADD CONSTRAINT resultadousuario_id_emocional_fkey FOREIGN KEY (id_emocional) REFERENCES public.tipoemocional(id_emocional);


--
-- Name: resultadousuario resultadousuario_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resultadousuario
    ADD CONSTRAINT resultadousuario_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_usuario);


--
-- Name: solicitudadopcion solicitudadopcion_id_mascota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitudadopcion
    ADD CONSTRAINT solicitudadopcion_id_mascota_fkey FOREIGN KEY (id_mascota) REFERENCES public.mascota(id_mascota);


--
-- Name: solicitudadopcion solicitudadopcion_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitudadopcion
    ADD CONSTRAINT solicitudadopcion_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_usuario);


--
-- PostgreSQL database dump complete
--

